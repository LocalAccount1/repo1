﻿Imports System.Data.SqlTypes
Imports System.Text.RegularExpressions
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class JackEnPoy
    Dim userBet As String = "" ' To store user's bet (Rock, Paper, or Scissors)
    Dim computerBet As String = "" ' To store computer's bet
    Dim random As New Random() ' Random number generator
    Private Property Bet As Integer
    Private Property money As Integer
    Dim choices As String() = {"Rock", "Paper", "Scissors"} ' Available choices

    Private Sub RockPictureBox_Click(sender As Object, e As EventArgs) Handles Rockpicturebox.Click
        userBet = "Rock"
        Betpicturebox.Image = My.Resources._1_rock ' Set the image in BetPictureBox
    End Sub

    Private Sub PaperPictureBox_Click(sender As Object, e As EventArgs) Handles Paperpicturebox.Click
        userBet = "Paper"
        Betpicturebox.Image = My.Resources._0_paper ' Set the image in BetPictureBox
    End Sub

    Private Sub ScissorsPictureBox_Click(sender As Object, e As EventArgs) Handles Scissorpicturebox.Click
        userBet = "Scissors"
        Betpicturebox.Image = My.Resources._2scissor ' Set the image in BetPictureBox
    End Sub

    Private Sub btnShow_Click(sender As Object, e As EventArgs) Handles Button1.Click

        'If String.IsNullOrEmpty(TextBox2.Text) Then
        '    MessageBox.Show("Please enter bet amount!")
        '    ' Exit the sub if no bet amount is selected
        'ElseIf Betpicturebox.Image Is Nothing Then
        '    MessageBox.Show("Please select a bet by clicking on Rock, Paper, or Scissors.")
        '    Exit Sub ' Exit the sub if no bet is selected
        'End If
        '
        '
        If String.IsNullOrEmpty(TextBox2.Text) Then
            MessageBox.Show("Please Enter bet Amount!")
        Else
            If Not IsNumeric(TextBox2.Text) And Regex.IsMatch(TextBox2.Text, "[^a-zA-Z0-9]") Then
                MsgBox("Input are not numeric")
            Else
                If Betpicturebox.Image Is Nothing Then
                    MessageBox.Show("Please select a bet by clicking on Rock, Paper, or Scissors.")
                Else
                    Bet = Convert.ToInt32(Bet.ToString())
                    Timer1.Start()

                End If

            End If

        End If

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim randomChoice As String = choices(random.Next(0, 3)) ' Randomly select a choice
        UpdateComputerPictureBox(randomChoice) ' Update PictureBox to simulate randomization

        ' Stop the timer after 3 seconds
        Static tickCount As Integer = 0
        tickCount += 1
        If tickCount >= 20 Then
            tickCount = 0
            Timer1.Stop() ' Stop the timer after 3 seconds
            computerBet = randomChoice ' Set the final computer's bet
            UpdateComputerPictureBox(computerBet) ' Update PictureBox with final choice

            ' Determine the winner and update user's money
            If userBet = computerBet Then
                MessageBox.Show("It's a draw!")
            ElseIf (userBet = "Rock" And computerBet = "Scissors") Or
                    (userBet = "Paper" And computerBet = "Rock") Or
                    (userBet = "Scissors" And computerBet = "Paper") Then
                MessageBox.Show("You win!")
                If Integer.TryParse(Label3.Text, money) Then
                    If Integer.TryParse(TextBox2.Text, Bet) Then
                        Label3.Text += Bet
                    End If
                    Label3.Text += Bet
                Else
                    MessageBox.Show("Computer wins!")
                    If Integer.TryParse(Label3.Text, money) Then
                        If Integer.TryParse(TextBox2.Text, Bet) Then
                            Label3.Text += Bet
                        End If
                        Label3.Text -= Bet
                    End If
                    tickCount = 0 ' Reset tick count for the next round
                End If
            End If
        End If
    End Sub

    Private Sub UpdateComputerPictureBox(choice As String)
        Select Case choice
            Case "Rock"
                AIpicturebox.Image = My.Resources.rock
            Case "Paper"
                AIpicturebox.Image = My.Resources.paper
            Case "Scissors"
                AIpicturebox.Image = My.Resources.scissor
        End Select
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'lblMoney.Text = "Money: P" & TextBox1.ToString()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form1.Show()
        Form1.Cashtext.Text = Label3.Text
        Me.Hide()
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

End Class