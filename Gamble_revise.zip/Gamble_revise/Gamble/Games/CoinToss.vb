﻿Imports System.Diagnostics.Eventing.Reader
Imports System.Reflection.Emit
Imports System.Runtime.InteropServices

Public Class CoinToss
    Private Property Random As New Random
    Private Property count As Integer
    Private Property int As Integer

    Private Property Bet As Integer

    Private Property money As Integer


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Backbtn.Click
        Form1.Show()
        Form1.Cashtext.Text = Label1.Text
        Me.Hide()
    End Sub

    Private Sub CoinToss_Load(sender As Object, e As EventArgs) Handles MyBase.Load


    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

        Select Case ComboBox1.SelectedIndex
            Case 0
                PictureBox1.Image = Nothing
            Case 1
                PictureBox1.Image = Image.FromFile(Application.StartupPath & "/Images/coins.png")
            Case 2
                PictureBox1.Image = Image.FromFile(Application.StartupPath & "/Images/tails.png")
        End Select

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        count += 1
        int = Random.Next(1, 3)
        ComboBox2.SelectedIndex = int
        If count = 50 Then
            Timer1.Stop()
            count = 0
            If ComboBox1.SelectedIndex = ComboBox2.SelectedIndex Then
                MessageBox.Show("You win!")
                If Integer.TryParse(Label1.Text, money) Then
                    If Integer.TryParse(TextBox1.Text, Bet) Then
                        Label1.Text += Bet
                    End If

                End If
            Else
                MessageBox.Show("You Lose!!")
                If Integer.TryParse(Label1.Text, money) Then
                    If Integer.TryParse(TextBox1.Text, Bet) Then
                        Label1.Text -= Bet

                    End If

                End If

            End If


        End If
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged

        Select Case ComboBox2.SelectedIndex
            Case 0
                PictureBox2.Image = Nothing
            Case 1
                PictureBox2.Image = Image.FromFile(Application.StartupPath & "/Images/coins.png")
            Case 2
                PictureBox2.Image = Image.FromFile(Application.StartupPath & "/Images/tails.png")
        End Select
    End Sub

    Private Sub Spinbtn_Click(sender As Object, e As EventArgs) Handles Spinbtn.Click

        If String.IsNullOrEmpty(TextBox1.Text) Then
            MessageBox.Show("Put your bet first!!")
        Else
            Timer1.Start()
        End If



    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class