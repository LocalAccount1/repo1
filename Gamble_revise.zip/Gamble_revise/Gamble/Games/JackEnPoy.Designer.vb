﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class JackEnPoy
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Rockpicturebox = New System.Windows.Forms.PictureBox()
        Me.Scissorpicturebox = New System.Windows.Forms.PictureBox()
        Me.Paperpicturebox = New System.Windows.Forms.PictureBox()
        Me.AIpicturebox = New System.Windows.Forms.PictureBox()
        Me.Betpicturebox = New System.Windows.Forms.PictureBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.Rockpicturebox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Scissorpicturebox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Paperpicturebox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AIpicturebox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Betpicturebox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Rockpicturebox
        '
        Me.Rockpicturebox.Image = Global.Games.My.Resources.Resources.rock
        Me.Rockpicturebox.Location = New System.Drawing.Point(12, 12)
        Me.Rockpicturebox.Name = "Rockpicturebox"
        Me.Rockpicturebox.Size = New System.Drawing.Size(114, 90)
        Me.Rockpicturebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Rockpicturebox.TabIndex = 0
        Me.Rockpicturebox.TabStop = False
        '
        'Scissorpicturebox
        '
        Me.Scissorpicturebox.Image = Global.Games.My.Resources.Resources.scissor
        Me.Scissorpicturebox.Location = New System.Drawing.Point(306, 12)
        Me.Scissorpicturebox.Name = "Scissorpicturebox"
        Me.Scissorpicturebox.Size = New System.Drawing.Size(114, 90)
        Me.Scissorpicturebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Scissorpicturebox.TabIndex = 1
        Me.Scissorpicturebox.TabStop = False
        '
        'Paperpicturebox
        '
        Me.Paperpicturebox.Image = Global.Games.My.Resources.Resources.paper
        Me.Paperpicturebox.Location = New System.Drawing.Point(156, 12)
        Me.Paperpicturebox.Name = "Paperpicturebox"
        Me.Paperpicturebox.Size = New System.Drawing.Size(114, 90)
        Me.Paperpicturebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Paperpicturebox.TabIndex = 2
        Me.Paperpicturebox.TabStop = False
        '
        'AIpicturebox
        '
        Me.AIpicturebox.Location = New System.Drawing.Point(285, 180)
        Me.AIpicturebox.Name = "AIpicturebox"
        Me.AIpicturebox.Size = New System.Drawing.Size(114, 90)
        Me.AIpicturebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.AIpicturebox.TabIndex = 3
        Me.AIpicturebox.TabStop = False
        '
        'Betpicturebox
        '
        Me.Betpicturebox.Location = New System.Drawing.Point(27, 180)
        Me.Betpicturebox.Name = "Betpicturebox"
        Me.Betpicturebox.Size = New System.Drawing.Size(114, 90)
        Me.Betpicturebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Betpicturebox.TabIndex = 4
        Me.Betpicturebox.TabStop = False
        '
        'Timer1
        '
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(588, 203)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(123, 67)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "Start"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(620, 124)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(91, 20)
        Me.TextBox2.TabIndex = 7
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(539, 124)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(23, 13)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Bet"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(722, 12)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(66, 50)
        Me.Button2.TabIndex = 10
        Me.Button2.Text = "Back"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label3.Location = New System.Drawing.Point(628, 70)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(66, 32)
        Me.Label3.TabIndex = 11
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(539, 70)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 13)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Money:"
        '
        'JackEnPoy
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Betpicturebox)
        Me.Controls.Add(Me.AIpicturebox)
        Me.Controls.Add(Me.Paperpicturebox)
        Me.Controls.Add(Me.Scissorpicturebox)
        Me.Controls.Add(Me.Rockpicturebox)
        Me.Name = "JackEnPoy"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "JackEnPoy"
        CType(Me.Rockpicturebox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Scissorpicturebox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Paperpicturebox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AIpicturebox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Betpicturebox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Rockpicturebox As PictureBox
    Friend WithEvents Scissorpicturebox As PictureBox
    Friend WithEvents Paperpicturebox As PictureBox
    Friend WithEvents AIpicturebox As PictureBox
    Friend WithEvents Betpicturebox As PictureBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Button1 As Button
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label1 As Label
End Class
