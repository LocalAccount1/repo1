﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Lucky9Btn = New System.Windows.Forms.Button()
        Me.CFlipBtn = New System.Windows.Forms.Button()
        Me.JackBtn = New System.Windows.Forms.Button()
        Me.SlotBtn = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Cashtext = New System.Windows.Forms.TextBox()
        Me.Input = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Lucky9Btn
        '
        Me.Lucky9Btn.Enabled = False
        Me.Lucky9Btn.Location = New System.Drawing.Point(128, 230)
        Me.Lucky9Btn.Name = "Lucky9Btn"
        Me.Lucky9Btn.Size = New System.Drawing.Size(95, 56)
        Me.Lucky9Btn.TabIndex = 0
        Me.Lucky9Btn.Text = "Lucky9"
        Me.Lucky9Btn.UseVisualStyleBackColor = True
        '
        'CFlipBtn
        '
        Me.CFlipBtn.Enabled = False
        Me.CFlipBtn.Location = New System.Drawing.Point(324, 239)
        Me.CFlipBtn.Name = "CFlipBtn"
        Me.CFlipBtn.Size = New System.Drawing.Size(108, 56)
        Me.CFlipBtn.TabIndex = 1
        Me.CFlipBtn.Text = "CoinFlip"
        Me.CFlipBtn.UseVisualStyleBackColor = True
        '
        'JackBtn
        '
        Me.JackBtn.Enabled = False
        Me.JackBtn.Location = New System.Drawing.Point(128, 326)
        Me.JackBtn.Name = "JackBtn"
        Me.JackBtn.Size = New System.Drawing.Size(95, 54)
        Me.JackBtn.TabIndex = 2
        Me.JackBtn.Text = "Jacken"
        Me.JackBtn.UseVisualStyleBackColor = True
        '
        'SlotBtn
        '
        Me.SlotBtn.Enabled = False
        Me.SlotBtn.Location = New System.Drawing.Point(324, 326)
        Me.SlotBtn.Name = "SlotBtn"
        Me.SlotBtn.Size = New System.Drawing.Size(102, 54)
        Me.SlotBtn.TabIndex = 3
        Me.SlotBtn.Text = "SlotMachine"
        Me.SlotBtn.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.InactiveBorder
        Me.Label1.Location = New System.Drawing.Point(49, 96)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(132, 25)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Input Cash:"
        '
        'Cashtext
        '
        Me.Cashtext.Location = New System.Drawing.Point(196, 96)
        Me.Cashtext.Multiline = True
        Me.Cashtext.Name = "Cashtext"
        Me.Cashtext.Size = New System.Drawing.Size(195, 33)
        Me.Cashtext.TabIndex = 5
        '
        'Input
        '
        Me.Input.Location = New System.Drawing.Point(235, 172)
        Me.Input.Name = "Input"
        Me.Input.Size = New System.Drawing.Size(84, 23)
        Me.Input.TabIndex = 6
        Me.Input.Text = "Enter"
        Me.Input.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(738, 450)
        Me.Controls.Add(Me.Input)
        Me.Controls.Add(Me.Cashtext)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.SlotBtn)
        Me.Controls.Add(Me.JackBtn)
        Me.Controls.Add(Me.CFlipBtn)
        Me.Controls.Add(Me.Lucky9Btn)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Lucky9Btn As Button
    Friend WithEvents CFlipBtn As Button
    Friend WithEvents JackBtn As Button
    Friend WithEvents SlotBtn As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Cashtext As TextBox
    Friend WithEvents Input As Button
End Class
