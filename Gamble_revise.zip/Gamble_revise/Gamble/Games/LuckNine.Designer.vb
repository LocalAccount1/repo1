﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LuckNine
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Usercard1 = New System.Windows.Forms.PictureBox()
        Me.Usercard3 = New System.Windows.Forms.PictureBox()
        Me.Usercard2 = New System.Windows.Forms.PictureBox()
        Me.AIcard1 = New System.Windows.Forms.PictureBox()
        Me.AIcard3 = New System.Windows.Forms.PictureBox()
        Me.AIcard2 = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Cartabtn = New System.Windows.Forms.Button()
        Me.Showbtn = New System.Windows.Forms.Button()
        Me.Getcardbtn = New System.Windows.Forms.Button()
        Me.usercards = New System.Windows.Forms.Label()
        Me.comcards = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.BETLbl = New System.Windows.Forms.Label()
        CType(Me.Usercard1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Usercard3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Usercard2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AIcard1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AIcard3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AIcard2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label1.Location = New System.Drawing.Point(496, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(151, 61)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "100"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(653, 9)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(135, 61)
        Me.Button3.TabIndex = 3
        Me.Button3.Text = "back"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Usercard1
        '
        Me.Usercard1.Location = New System.Drawing.Point(54, 95)
        Me.Usercard1.Name = "Usercard1"
        Me.Usercard1.Size = New System.Drawing.Size(77, 110)
        Me.Usercard1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Usercard1.TabIndex = 4
        Me.Usercard1.TabStop = False
        '
        'Usercard3
        '
        Me.Usercard3.Location = New System.Drawing.Point(336, 95)
        Me.Usercard3.Name = "Usercard3"
        Me.Usercard3.Size = New System.Drawing.Size(77, 110)
        Me.Usercard3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Usercard3.TabIndex = 5
        Me.Usercard3.TabStop = False
        '
        'Usercard2
        '
        Me.Usercard2.Location = New System.Drawing.Point(194, 95)
        Me.Usercard2.Name = "Usercard2"
        Me.Usercard2.Size = New System.Drawing.Size(77, 110)
        Me.Usercard2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Usercard2.TabIndex = 6
        Me.Usercard2.TabStop = False
        '
        'AIcard1
        '
        Me.AIcard1.Location = New System.Drawing.Point(54, 279)
        Me.AIcard1.Name = "AIcard1"
        Me.AIcard1.Size = New System.Drawing.Size(77, 110)
        Me.AIcard1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.AIcard1.TabIndex = 7
        Me.AIcard1.TabStop = False
        '
        'AIcard3
        '
        Me.AIcard3.Location = New System.Drawing.Point(336, 279)
        Me.AIcard3.Name = "AIcard3"
        Me.AIcard3.Size = New System.Drawing.Size(77, 110)
        Me.AIcard3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.AIcard3.TabIndex = 8
        Me.AIcard3.TabStop = False
        '
        'AIcard2
        '
        Me.AIcard2.Location = New System.Drawing.Point(194, 279)
        Me.AIcard2.Name = "AIcard2"
        Me.AIcard2.Size = New System.Drawing.Size(77, 110)
        Me.AIcard2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.AIcard2.TabIndex = 9
        Me.AIcard2.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(396, 36)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(83, 25)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Money:"
        '
        'Cartabtn
        '
        Me.Cartabtn.Location = New System.Drawing.Point(662, 107)
        Me.Cartabtn.Name = "Cartabtn"
        Me.Cartabtn.Size = New System.Drawing.Size(126, 44)
        Me.Cartabtn.TabIndex = 11
        Me.Cartabtn.Text = "Carta"
        Me.Cartabtn.UseVisualStyleBackColor = True
        '
        'Showbtn
        '
        Me.Showbtn.Location = New System.Drawing.Point(662, 207)
        Me.Showbtn.Name = "Showbtn"
        Me.Showbtn.Size = New System.Drawing.Size(126, 48)
        Me.Showbtn.TabIndex = 12
        Me.Showbtn.Text = "Show"
        Me.Showbtn.UseVisualStyleBackColor = True
        '
        'Getcardbtn
        '
        Me.Getcardbtn.Location = New System.Drawing.Point(662, 157)
        Me.Getcardbtn.Name = "Getcardbtn"
        Me.Getcardbtn.Size = New System.Drawing.Size(126, 44)
        Me.Getcardbtn.TabIndex = 13
        Me.Getcardbtn.Text = "Get card"
        Me.Getcardbtn.UseVisualStyleBackColor = True
        '
        'usercards
        '
        Me.usercards.AutoSize = True
        Me.usercards.Location = New System.Drawing.Point(92, 45)
        Me.usercards.Name = "usercards"
        Me.usercards.Size = New System.Drawing.Size(33, 13)
        Me.usercards.TabIndex = 14
        Me.usercards.Text = "YOU:"
        '
        'comcards
        '
        Me.comcards.AutoSize = True
        Me.comcards.Location = New System.Drawing.Point(191, 45)
        Me.comcards.Name = "comcards"
        Me.comcards.Size = New System.Drawing.Size(20, 13)
        Me.comcards.TabIndex = 15
        Me.comcards.Text = "AI:"
        '
        'TextBox1
        '
        Me.TextBox1.Enabled = False
        Me.TextBox1.Location = New System.Drawing.Point(137, 38)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(42, 20)
        Me.TextBox1.TabIndex = 16
        '
        'TextBox2
        '
        Me.TextBox2.Enabled = False
        Me.TextBox2.Location = New System.Drawing.Point(236, 38)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(42, 20)
        Me.TextBox2.TabIndex = 17
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(525, 131)
        Me.TextBox3.Multiline = True
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(69, 20)
        Me.TextBox3.TabIndex = 18
        '
        'BETLbl
        '
        Me.BETLbl.AutoSize = True
        Me.BETLbl.Location = New System.Drawing.Point(493, 135)
        Me.BETLbl.Name = "BETLbl"
        Me.BETLbl.Size = New System.Drawing.Size(26, 13)
        Me.BETLbl.TabIndex = 19
        Me.BETLbl.Text = "Bet:"
        '
        'LuckNine
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.BETLbl)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.comcards)
        Me.Controls.Add(Me.usercards)
        Me.Controls.Add(Me.Getcardbtn)
        Me.Controls.Add(Me.Showbtn)
        Me.Controls.Add(Me.Cartabtn)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.AIcard2)
        Me.Controls.Add(Me.AIcard3)
        Me.Controls.Add(Me.AIcard1)
        Me.Controls.Add(Me.Usercard2)
        Me.Controls.Add(Me.Usercard3)
        Me.Controls.Add(Me.Usercard1)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Label1)
        Me.Name = "LuckNine"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "LuckNine"
        CType(Me.Usercard1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Usercard3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Usercard2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AIcard1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AIcard3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AIcard2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents Usercard1 As PictureBox
    Friend WithEvents Usercard3 As PictureBox
    Friend WithEvents Usercard2 As PictureBox
    Friend WithEvents AIcard1 As PictureBox
    Friend WithEvents AIcard3 As PictureBox
    Friend WithEvents AIcard2 As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Cartabtn As Button
    Friend WithEvents Showbtn As Button
    Friend WithEvents Getcardbtn As Button
    Friend WithEvents usercards As Label
    Friend WithEvents comcards As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents BETLbl As Label
End Class
