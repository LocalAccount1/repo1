﻿Imports System.Security.Policy

Public Class Form1

    'Public Shared Balance As Double

    'Private cash As Double = 0
    Private Sub CashInButton_Click(sender As Object, e As EventArgs) Handles Input.Click
        If Cashtext.Text = String.Empty Or Cashtext.Text <= 0 Then
            MessageBox.Show("Enter a Money")
        Else
            CFlipBtn.Enabled = True
            JackBtn.Enabled = True
            Lucky9Btn.Enabled = True
            SlotBtn.Enabled = True
        End If

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Lucky9Btn_Click(sender As Object, e As EventArgs) Handles Lucky9Btn.Click
        LuckNine.Show()
        LuckNine.Label1.Text = Cashtext.Text
        Me.Hide()
    End Sub

    Private Sub JackBtn_Click(sender As Object, e As EventArgs) Handles JackBtn.Click
        JackEnPoy.Show()
        JackEnPoy.Label3.Text = Cashtext.Text
        Me.Hide()
    End Sub

    Private Sub SlotBtn_Click(sender As Object, e As EventArgs) Handles SlotBtn.Click
        SlotMachine.Show()
        SlotMachine.Money.Text = Cashtext.Text
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles CFlipBtn.Click
        CoinToss.Show()
        CoinToss.Label1.Text = Cashtext.Text
        Me.Hide()
    End Sub

End Class