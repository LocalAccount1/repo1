﻿Public Class SlotMachine
    Dim m, a, b, c As Integer
    Dim totalIterations As Integer = 250 ' 20ms * 250 = 5000ms = 5 seconds
    Dim betAmount As Integer = 0

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Check if the bet amount is entered in the TextBox
        If String.IsNullOrEmpty(TextBox1.Text) Then
            MessageBox.Show("Please enter a bet amount!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            ' Reset the iteration count and starting the timer
            m = 0
            'Starting the timer
            Timer1.Enabled = True
            'Disable the spin button
            Button1.Enabled = False

            ' Get the bet amount from the user input
            If Integer.TryParse(TextBox1.Text, betAmount) Then
                ' Check if the bet amount is within the user's available money
                If TextBox1.Text > Money.Text Then
                    MessageBox.Show("You don't have enough money to place this bet!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    ' Re-enable the spin button
                    Button1.Enabled = True
                Else
                    ' Deduct the bet amount from the user's pot money
                    Money.Text -= TextBox1.Text
                End If
            Else
                MessageBox.Show("Invalid bet amount! Please enter a valid number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                ' Re-enable the spin button
                Button1.Enabled = True
            End If

            ' Update the pot money label

        End If
    End Sub

    'Public Shared Property CashInput As Double
    Private Sub SlotMachine_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Seed the random number generator
        Randomize()
        ' Set the timer interval to 20 milliseconds
        Timer1.Interval = 20

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click, Label2.Click

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Form1.Show()
        Form1.Cashtext.Text = Money.Text
        Me.Hide()

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        m = m + 10
        If m < 3000 Then
            If m < 1000 Then
                a = Int(1 + Rnd() * 4) ' 4 options (Banana, Lemon, Cherry, 7)
                b = Int(1 + Rnd() * 4)
                c = Int(1 + Rnd() * 4)

                Select Case a
                    Case 1
                        PictureBox2.Image = My.Resources.banana
                    Case 2
                        PictureBox2.Image = My.Resources.cherry
                    Case 3
                        PictureBox2.Image = My.Resources.lemon
                    Case 4
                        PictureBox2.Image = My.Resources.seven
                End Select
            End If
            If m < 2000 Then
                b = Int(1 + Rnd() * 4)
                c = Int(1 + Rnd() * 4)

                Select Case b
                    Case 1
                        PictureBox3.Image = My.Resources.banana
                    Case 2
                        PictureBox3.Image = My.Resources.cherry
                    Case 3
                        PictureBox3.Image = My.Resources.lemon
                    Case 4
                        PictureBox3.Image = My.Resources.seven
                End Select
            End If
            If m < 3000 Then
                c = Int(1 + Rnd() * 4)

                Select Case c
                    Case 1
                        PictureBox4.Image = My.Resources.banana
                    Case 2
                        PictureBox4.Image = My.Resources.cherry
                    Case 3
                        PictureBox4.Image = My.Resources.lemon
                    Case 4
                        PictureBox4.Image = My.Resources.seven
                End Select
            End If
        Else
            Timer1.Enabled = False
            Button1.Enabled = True
            m = 0

            CheckResult()
        End If
    End Sub

    Private Sub SetProbabilities()
        Dim randomValue As Integer = Int(1 + Rnd() * 100)

        If randomValue <= 40 Then
            ' 40 percent for the images of seven
            a = 4 ' Seven
            b = 4 ' Seven
            c = 4 ' Seven
        ElseIf randomValue <= 90 Then
            ' 50 percent for all the fruits (Banana, Lemon, Cherry)
            a = Int(1 + Rnd() * 3)
            b = Int(1 + Rnd() * 3)
            c = Int(1 + Rnd() * 3)
        Else
            a = 0
            b = 0
            c = 0
        End If
    End Sub

    Private Sub CheckResult()
        Dim fruitNames As String() = {"Banana", "Cherry", "Lemon", "Seven"}

        If (a >= 1 And a <= 3) And (a = b Or a = c) Then ' 2 of the same fruit
            Dim fruitName As String = fruitNames(a - 1) ' Get the name of the fruit based on index (1-based to 0-based)
            Money.Text += betAmount * 2 ' Double the bet amount
            MessageBox.Show($"Congratulations! You won ₱{(betAmount * 2).ToString()} with 2 {fruitName}s!", "Winner!", MessageBoxButtons.OK, MessageBoxIcon.Information)
        ElseIf (a = b And a = c And b = c) OrElse (a = b And b = c And c = a) Then ' 3 of the same fruit
            Dim fruitName As String = fruitNames(a - 1) ' Get the name of the fruit based on index (1-based to 0-based)
            Money.Text += betAmount * 3 ' Triple the bet amount
            MessageBox.Show($"Congratulations! You won ₱{(betAmount * 3).ToString()} with 3 {fruitName}s!", "Winner!", MessageBoxButtons.OK, MessageBoxIcon.Information)
        ElseIf (a = 4 And b = 4 And c <> 4) OrElse (b = 4 And c = 4 And a <> 4) OrElse (a = 4 And c = 4 And b <> 4) Then ' 2 Sevens
            Money.Text += betAmount * 4 ' Quadruple the bet amount
            MessageBox.Show($"Congratulations! You won ₱{(betAmount * 4).ToString()} with 2 Sevens!", "Winner!", MessageBoxButtons.OK, MessageBoxIcon.Information)
        ElseIf (a = 4 And b = 4 And c = 4) Then ' 3 Sevens
            Money.Text += 100000 ' Payout jackpot
            Dim fruitName As String = fruitNames(3) ' Get the name of Seven based on index
            MessageBox.Show($"Congratulations! You won the jackpot of ₱100,000 with 3 {fruitName}s!", "Winner!", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            MessageBox.Show($"No luck! You lost ₱{betAmount.ToString()}.", "Try again!", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

        ' Update the pot money label

    End Sub

End Class