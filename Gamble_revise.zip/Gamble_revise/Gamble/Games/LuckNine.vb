﻿Imports System.Security.Policy

Public Class LuckNine
    Private rnd As New Random()
    Private bet As Integer 'to hold the user's bet amount
    Private Playercard As New List(Of String)() 'to hold the user's chosen cards
    Private Aicard As New List(Of String)() 'to hold the computer's chosen cards
    Private Property money As Integer

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Cartabtn.Enabled = False
        Showbtn.Enabled = False
        Getcardbtn.Enabled = False
    End Sub

    Private CardImages As New Dictionary(Of String, Image) From {
          {"_AC", My.Resources._AC},
          {"_AS", My.Resources._AS},
          {"_AD", My.Resources._AD},
          {"_AH", My.Resources._AH},
          {"_2C", My.Resources._2C},
          {"_2S", My.Resources._2S},
          {"_2D", My.Resources._2D},
          {"_2H", My.Resources._2H},
          {"_3C", My.Resources._3C},
          {"_3S", My.Resources._3S},
          {"_3D", My.Resources._3D},
          {"_3H", My.Resources._3H},
          {"_4C", My.Resources._4C},
          {"_4S", My.Resources._4S},
          {"_4D", My.Resources._4D},
          {"_4H", My.Resources._4H},
          {"_5C", My.Resources._5C},
          {"_5S", My.Resources._5S},
          {"_5D", My.Resources._5D},
          {"_5H", My.Resources._5H},
          {"_6C", My.Resources._6C},
          {"_6S", My.Resources._6S},
          {"_6D", My.Resources._6D},
          {"_6H", My.Resources._6H},
          {"_7C", My.Resources._7C},
          {"_7S", My.Resources._7S},
          {"_7D", My.Resources._7D},
          {"_7H", My.Resources._7H},
          {"_8C", My.Resources._8C},
          {"_8S", My.Resources._8S},
          {"_8D", My.Resources._8D},
          {"_8H", My.Resources._8H},
          {"_9C", My.Resources._9C},
          {"_9S", My.Resources._9S},
          {"_9D", My.Resources._9D},
          {"_9H", My.Resources._9H}
      }

    Private cardValues As New Dictionary(Of String, Integer) From {
        {"_AC", 1},
        {"_AS", 1},
        {"_AD", 1},
        {"_AH", 1},
        {"_2C", 2},
        {"_2S", 2},
        {"_2D", 2},
        {"_2H", 2},
        {"_3C", 3},
        {"_3S", 3},
        {"_3D", 3},
        {"_3H", 3},
        {"_4C", 4},
        {"_4S", 4},
        {"_4D", 4},
        {"_4H", 4},
        {"_5C", 5},
        {"_5S", 5},
        {"_5D", 5},
        {"_5H", 5},
        {"_6C", 6},
        {"_6S", 6},
        {"_6D", 6},
        {"_6H", 6},
        {"_7C", 7},
        {"_7S", 7},
        {"_7D", 7},
        {"_7H", 7},
        {"_8C", 8},
        {"_8S", 8},
        {"_8D", 8},
        {"_8H", 8},
        {"_9C", 9},
        {"_9S", 9},
        {"_9D", 9},
        {"_9H", 9}
    } 'dictionary to hold the values of each card

    Private Sub btnGetCard_Click(sender As Object, e As EventArgs) Handles Getcardbtn.Click
        Showbtn.Enabled = True
        'get two random cards for the user
        Dim card1 As String = GetRandomCard()
        Dim card2 As String = GetRandomCard()

        'add the cards to the userCards list and display the images
        Playercard.Add(card1)
        Playercard.Add(card2)
        Usercard1.Image = CardImages(card1)
        Usercard2.Image = CardImages(card2)

        Cartabtn.Enabled = True 'enable the "carta" button for additional card
        Getcardbtn.Enabled = False 'disable the "get card" button
    End Sub

    Private Sub btnCarta_Click(sender As Object, e As EventArgs) Handles Cartabtn.Click
        'get one more random card for the user
        Dim card As String = GetRandomCard()

        'add the card to the userCards list and display the image
        Playercard.Add(card)
        Usercard3.Image = CardImages(card)

        Cartabtn.Enabled = False 'disable the "carta" button
    End Sub

    Private Sub btnShow_Click(sender As Object, e As EventArgs) Handles Showbtn.Click
        'get two random cards for the computer
        Dim card1 As String = GetRandomCard()
        Dim card2 As String = GetRandomCard()

        'add the cards to the comCards list and display the images
        Aicard.Add(card1)
        Aicard.Add(card2)
        AIcard1.Image = CardImages(card1)
        AIcard2.Image = CardImages(card2)

        'calculate the computer's total
        Dim comTotal As Integer = CalculateTotal(Aicard)

        'if the computer's total is less than or equal to 4, it will draw a third card
        If comTotal <= 4 Then
            'get one more random card for the computer
            Dim card3 As String = GetRandomCard()

            'add the card to the comCards list and display the image
            Aicard.Add(card3)
            AIcard3.Image = CardImages(card3)
        End If

        Showbtn.Enabled = False 'disable the "show" button for the computer

        'calculate each player's total
        Dim userTotal As Integer = CalculateTotal(Playercard)
        comTotal = CalculateTotal(Aicard)

        TextBox1.Text = userTotal
        TextBox2.Text = comTotal

        'check who wins
        If userTotal > comTotal AndAlso userTotal <= 9 Then
            MsgBox("You win!")
            If Integer.TryParse(Label1.Text, money) Then
                If Integer.TryParse(TextBox3.Text, bet) Then
                    Label1.Text += bet 'add the bet amount to the current money
                End If
            End If
            If comTotal > userTotal AndAlso comTotal <= 9 Then
                MsgBox("Computer wins!")
                If Integer.TryParse(Label1.Text, money) Then
                    Integer.TryParse(TextBox3.Text, bet)
                    Label1.Text -= bet 'subtract the bet amount from the current money
                End If
                If userTotal = comTotal Then
                    MsgBox("Tie!")
                Else
                    MsgBox("Busted!")
                    Label1.Text -= bet 'subtract the bet amount from the current money
                End If
            End If
        End If

        'reset the game
        ResetGame()
    End Sub

    Private Function GetRandomCard() As String
        'get a random card from the CardImages dictionary
        Dim index As Integer = rnd.Next(0, CardImages.Keys.Count)
        Return CardImages.Keys.ElementAt(index)
    End Function

    Private Function CalculateTotal(cards As List(Of String)) As Integer
        Dim total As Integer = 0
        For Each card In cards
            total += cardValues(card)
        Next
        Return total Mod 10 'mod to 10 to disregard the 10s in lucky 9
    End Function

    Private Sub ResetGame()
        'reset the game by clearing the lists and pictureboxes
        Playercard.Clear()
        Aicard.Clear()
        Usercard1.Image = Nothing
        Usercard2.Image = Nothing
        Usercard3.Image = Nothing
        AIcard1.Image = Nothing
        AIcard2.Image = Nothing
        AIcard3.Image = Nothing

        Getcardbtn.Enabled = True 'enable the "get card" button
        Cartabtn.Enabled = False 'disable the "carta" button
        Showbtn.Enabled = False 'enable the "show" button for the computer

    End Sub

    Private Sub LuckNine_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Form1.Show()
        Form1.Cashtext.Text = Label1.Text
        Me.Hide()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged
        If TextBox3.Text = String.Empty Or TextBox3.Text <= 0 Then
            MessageBox.Show("Enter your bet!")
        Else
            Showbtn.Enabled = True
            Cartabtn.Enabled = True
            Getcardbtn.Enabled = True
        End If
    End Sub

End Class